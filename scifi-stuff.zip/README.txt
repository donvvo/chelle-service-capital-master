A Pen created at CodePen.io. You can find this one at https://codepen.io/marioluevanos/pen/XKqNkB.

 A project that didn't go anywhere. Took the header of that Scifi project and used it for Codepen. Code is ugly and horrible. 